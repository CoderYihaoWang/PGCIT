Challenge 03
==========
This challenge is worth **3%** of the final grade.

The instruction can be found in `industry_challenge_03.pdf`.

You should have the following source files in this project:
- Util.Keyboard.java
- productList.csv
